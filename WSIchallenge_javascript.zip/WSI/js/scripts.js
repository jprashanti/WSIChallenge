var wsiScript = (function(){
	return {

		bindProductViewerHandler: function() {
			/* Handles the Product Viewer Section */
			var productThumbsList = document.getElementById('product-thumbs-list');
			var largeThumbnail = document.getElementById('large-thumbnail');
			var productLinks = productThumbsList.querySelectorAll('.small-thumb') || [];
			for(var i = 0; i< productLinks.length; i++) {
			    productLinks[i].onclick = function() {
			    	console.log('test')
			    	var activeEle = productThumbsList.querySelector('.active');
			    	activeEle.classList.toggle('active');
			    	this.classList.toggle('active');
			   		largeThumbnail.src = this.getAttribute('data-img');
			    }
			}

		},

		bindAccordionHandler: function() {
			/* Handles Accordion Functionality */
			var accordion = document.getElementById('accordion');
			var accrTitles = accordion.getElementsByClassName('accr-title') || [];
			for(var i = 0; i< accrTitles.length; i++) {
			    accrTitles[i].onclick = function() {
			   		this.parentElement.classList.toggle("expanded");
			    }
			}
		},

		openModalPopup: function(mId) {
			var modal = document.getElementById(mId);
			modal.style.display = 'block';
			var closeBtn = modal.getElementsByClassName('close-btn')[0];
			closeBtn.addEventListener('click', function() {
				modal.style.display = '';
			})
		},

		bindModalHandler: function() {
			/* Handles the Modal Pop Up */
			var this_ = this;
			var modalTriggers = document.getElementsByClassName('modal-trigger');
			for(var i = 0; i< modalTriggers.length; i++) {
			    modalTriggers[i].onclick = function() {
			    	var modalId = this.getAttribute('data-target');
			   		this_.openModalPopup(modalId);
			    }
			}

		},

		init: function() {
			/* Initialize All the Javascript Events Here */
			this.bindProductViewerHandler();
			this.bindAccordionHandler();
			this.bindModalHandler();
		}

	}
})();

wsiScript.init();